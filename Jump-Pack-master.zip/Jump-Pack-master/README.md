# Jump pack
- Automatically searches for games stored on your local PC on startup.
- Provides a simple graphical user interface to compare and run all of 
your games!
- Get the latest news about upcoming game releases from the suggestion 
page or search through our game store to find new games to play.
- Does not require the internet to function which makes for a simple 
alternative to steam or discord.

# Our team
 - James - Developer
 - Ahmed - Database design
 - Vihan - UX & UI
 - Ricky - Plan meetings Developer
 - Jose	- Developer
 - Liam - Developer

# Project road map
 - [x] Project plan proposal
 - [x] Software requirements specification
 - [x] Design documentation
 - [ ] Prototype (demo and code)
 - [ ] Final submission 

