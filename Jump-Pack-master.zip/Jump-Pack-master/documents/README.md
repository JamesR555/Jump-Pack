# Documents
- [x] Project plan proposal
- [x] Software specification requirements
- [ ] Design documentation

